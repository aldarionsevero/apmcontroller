
128 eeprom binary read from our original chip - use this to flash the chip (using ./ftdi_write_eeprom) if you somehow mangle it.
