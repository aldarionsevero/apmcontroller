# gazebo_ros_pkgs

Wrappers, tools and additional API's for using ROS with the Gazebo simulator. Formally simulator_gazebo stack, gazebo_pkgs is a meta package. Now Catkinized and works with the standalone Gazebo debian.

### Installation
[Installing gazebo_ros_pkgs](http://gazebosim.org/wiki/Tutorials/1.9/Installing_gazebo_ros_Packages)

### Documentation and Tutorials
[On gazebosim.org](http://gazebosim.org/wiki/Tutorials#ROS_Integration)

### Develop and Contribute

See [Contribute](https://github.com/ros-simulation/gazebo_ros_pkgs/blob/hydro-devel/CONTRIBUTING.md) page.


