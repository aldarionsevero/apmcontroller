yujin_open_control_system (yocs)
================================

Yujin Robot's open-source control system including libraries and exectuables