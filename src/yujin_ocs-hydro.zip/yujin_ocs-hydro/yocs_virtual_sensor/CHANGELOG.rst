^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_virtual_sensor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.3 (2014-03-24)
------------------

0.5.2 (2013-11-05)
------------------
* Current implementation cannot read obstacles from YAML files. Until this
  feature gets implemented, we use auxiliary scripts to read and publish
  files' content. Data directory contains some example files.

0.5.1 (2013-10-14)
------------------
* Unify naming politics for binaries and plugins.

0.5.0 (2013-10-11)
------------------

0.4.1 (2013-10-08)
------------------
* Initial version: migrated here from https://github.com/yujinrobot/kobuki-x

0.4.0 (2013-09-23 11:17)
------------------------

0.3.0 (2013-07-02)
------------------

0.2.3 (2013-09-23 11:23)
------------------------

0.2.2 (2013-02-10)
------------------

0.2.1 (2013-02-08)
------------------

0.2.0 (2013-02-07)
------------------

0.1.3 (2013-01-08)
------------------

0.1.2 (2013-01-02)
------------------

0.1.1 (2012-12-21)
------------------

0.1.0 (2012-12-05)
------------------
